package com.jobapp.ananyaa.enumerated;

public enum Role {
      ADMIN, USER
}
