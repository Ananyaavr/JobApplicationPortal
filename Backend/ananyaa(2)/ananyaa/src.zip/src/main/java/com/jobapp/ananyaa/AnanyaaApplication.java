package com.jobapp.ananyaa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnanyaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnanyaaApplication.class, args);
	}

}
